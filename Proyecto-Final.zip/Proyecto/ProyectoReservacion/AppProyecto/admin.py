from django.contrib import admin
from .models import Libros

# Register your models here.
class LibrosAdmin(admin.ModelAdmin):
    list_display = ("nombre", "disponible")
    list_filter = ("nombre", "disponible")

admin.site.register(Libros, LibrosAdmin)


from django.shortcuts import render, HttpResponse, redirect, get_object_or_404
from django.template import Template, Context
from django.template import loader 
from django.shortcuts import render
from django.template.loader import get_template
from AppProyecto.models import Libros, Solicitudes, Ordenes
from django.core.paginator import Paginator
from django.core.mail import send_mail


def inicio(request):
    dic={"": ""}
    return render(request, "inicio.html", dic)

#Variable page para que sea la que cambie para la sig hoja.
#Variable numberPerItems es la que va a mostrar cuantos datos ensena la website.

def reservacion(request):
    lista = Libros.objects.filter(disponible = True)
    numberPerItems = request.GET.get("numberPerItems", "5")
    page = request.GET.get('page', 1)
    p = Paginator(lista, numberPerItems)
    try:
        currentPage= p.page(page)
    except:
        currentPage= p.page(1)

    if request.method == "POST":
        nombreLibro = request.POST.get("nombre", "1")
        Ordenes.objects.create(nombre= nombreLibro)
        libro = Libros.objects.get(nombre=nombreLibro)
        libro.disponible = False
        libro.save()
        print(currentPage.paginator.page_range)
        return redirect(f"/reservacion/?page={currentPage.number}&numberPerItems={numberPerItems}")
    
    dic = {"libros": currentPage, "numberPerItems" : numberPerItems}
    return render(request, "reservacion.html", dic)
        
def carrito(request):
    if request.method == "POST":
        Libros.objects.all().update(disponible=True)
        nombre = request.POST.get("nombreCliente", "1")
        telefono = request.POST.get("telefono", "1")
        correo = request.POST.get("correo", "1")
        detalle = Ordenes.objects.all()
        detalle_str = ', '.join(item.nombre for item in detalle)

        Solicitudes.objects.create(nombre = nombre, telefono = telefono, correo = correo, detalle = detalle_str)
        
        mensaje = f"{nombre}, los libros que usted compró son: {detalle_str}\nMuchas gracias"
        send_mail("Solicitud de libros", mensaje, "libreriahestia@hestia.com", ["apc1520@hotmail.com"], fail_silently=False )
        
        detalle.delete()

        return redirect("/datos_enviados_carrito/")

    numberPerItems = request.GET.get("numberPerItems",3)
    page = request.GET.get("page", "1")
    lista = Ordenes.objects.all()
    p = Paginator(lista, numberPerItems)
    ultimaPagina = p.num_pages

    try:
        currentPage= p.page(page) 
    except:
        currentPage= p.page(1) 

    dic= {"solicitudes": currentPage, "numberPerItems": numberPerItems, "ultimaPagina": ultimaPagina}
    return render(request, "carrito/carrito.html",dic)

    
def borrar_de_tabla(request):
     if request.method == "POST":
        detalle = Ordenes.objects.all()
        orden=Ordenes.objects.first()
        Libros.objects.all().update(disponible=True)
        orden.delete()
        return redirect("/carrito/")
    

def datos_enviados(request):
    dic={"" : ""}
    return render(request, "carrito/datos_enviados_carrito.html", dic)
    

def contacto(request):
    if request.method == "POST":
        nombre = request.POST.get("nombreCliente", "1")
        telefono = request.POST.get("telefono", "1")
        correo = request.POST.get("correo", "1")
        detalleCliente = request.POST.get("detalle","1")
        Solicitudes.objects.create(nombre = nombre, telefono = telefono, correo = correo,
                                detalle = detalleCliente)
        
        mensaje =  "Datos de cliente: \n\n" + "Nombre: " + nombre +"\n"+ "Telefono: " + telefono +"\n"+ "Correo: " + correo +"\n"+ "Libros solicitados: \n" + detalleCliente
        send_mail("Solicitud de libros", mensaje, "libreriahestia@hestia.com", ["apc1520@hotmail.com"], fail_silently=False )

        return redirect("/datos_enviados_cliente/")
    
    elif request.method == "GET":
        return render(request, "contacto_folder/contacto.html")
    
def datos_enviados_cliente(request):
    dic={"": ""}
    return render(request, "contacto_folder/datos_enviados_cliente.html", dic)



from django.db import models

class Libros(models.Model):
    nombre = models.CharField(max_length=50)
    imagen = models.CharField(max_length=100)
    disponible = models.BooleanField(default=True)

    def __str__(self):
        return "Nombre: %s, Disponible: %s" % (self.nombre, self.disponible)
    

class Ordenes(models.Model):
    nombre = models.CharField(max_length=50)
    detalle = models.CharField(max_length=100)
    correo = models.EmailField(max_length=254, default="")
    telefono = models.CharField(max_length=9)

class Solicitudes(models.Model):
    nombre = models.CharField(max_length=50)
    detalle = models.CharField(max_length=100)
    correo = models.EmailField(max_length=254, default="")
    telefono = models.CharField(max_length=9)



#def create(request):
   # c1=Libros.objects.create(nombre="Afterlove",imagen="afterlove.jpg",disponible=True)
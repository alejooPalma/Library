from django.urls import path, include
from AppProyecto import views

urlpatterns = [
    path("", views.inicio, name="inicio"),
    path("reservacion/", views.reservacion, name="reservacion"),
    path("carrito/", views.carrito, name="carrito"),
    path("contacto/", views.contacto, name="contacto"),
    path("datos_enviados_carrito/", views.datos_enviados, name="datos_enviados"),
    path("datos_enviados_cliente/", views.datos_enviados_cliente, name="datos_enviados_clientes"),
    path("borrar_de_tabla/", views.borrar_de_tabla, name="borrar_de_tabla"),
]



from django.apps import AppConfig


class AppproyectoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppProyecto'
